package test;

import org.openntf.domino.big.impl.IndexDatabase;

public class Test {
private IndexDatabase index;
}
