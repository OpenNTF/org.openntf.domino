/*
  version.h - Version defines.
*/

#define PVERS	L"1.60"         // wide string
#define PVERSA	 "1.60"         // ANSI string (windres 2.16.91 didn't like L)
#define PVERE	L"160"          // wide environment string
#define PVEREA	 "160"          // ANSI environment string
#define PVERB	1,6,0,0 	// binary (resource)
